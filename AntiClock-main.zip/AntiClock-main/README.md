# 没有反方向的钟 任务一
> Hello world
## Hi 很高兴认识大家！
### 学习Git的过程

- [x] 了解Git的作用
- [x] 了解GitKraken[^GitKraken]
- [ ] 学会Git的使用 
[^GitKraken]:一款以Git和版本控制为核心的可视化客户端
{www.gitkraken.com}

*初次接触Git，虽然对c++比较了解，但是Git对于我来说确实是一门全新的语言，经过学习后了解到这是制作大型项目的必需品，具有非常强大的整合能力，许多功能仍然等着我去探索*
### 学习Markdown的过程
学习后的第一反应：**这是什么神仙语言！**

在bilibili上搜索Markdown教程后学习
[Markdown教程](www.bilibili.com/video/BV1JA411h7Gw/?spm_id_from=333.337.search-card.all.click&vd_source=4a74b4ed420910a82360aac27508ea03"请叫我AXin的频道")

看完大佬的教程，学习成果颇丰
| 姓名 | 练习时长 | 爱好 |
| ---- |:---:| ---- |
|杨淼涵|两年半|唱跳rap篮球|

```c
#include<iostream.h>
int main()
{
   cout<<"我爱程序部"；
    return 0;
}
```
### 想要学习的东西
**如果有幸进入程序部学习，我希望学习c++、python、javascipt等语言，和小程序、软件的制作以及网页的开发，立志成为全栈工程师！**:smile::smile:

*最后给大家看看我好兄弟*

![我的兄弟](https://wx1.sinaimg.cn/orj360/003yHo7Nly1h6d8zcjq6hj60zk1be76y02.jpg)
